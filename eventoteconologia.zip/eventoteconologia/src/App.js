import logo from './logo.svg';
import './App.css';
import FormEvento from './componentes/FormEvento'

function App() {
  return (
      <FormEvento />
  );
}

export default App;

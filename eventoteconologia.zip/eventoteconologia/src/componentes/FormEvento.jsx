import React, { useState } from 'react';

export function FormEvento() {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [tipoParticipante, setTipoParticipante] = useState('estudante');
  const [turno, setTurno] = useState('manha');
  const [oficinas, setOficinas] = useState([]);
  const [aceiteRegulamento, setAceiteRegulamento] = useState(false);

  const handleOficina = (event) => {
    const { value, checked } = event.target;
    if (checked) {
      setOficinas((prev) => [...prev, value]);
    } else {
      setOficinas((prev) => prev.filter((item) => item !== value));
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    const dadosFormulario = {
      nome,
      email,
      tipoParticipante,
      turno,
      oficinas,
      aceiteRegulamento,
    };

    console.log('Dados do formulário enviados:', dadosFormulario);

    // Limpeza de todos os campos
    setNome('');
    setEmail('');
    setTipoParticipante('estudante');
    setTurno('manha');
    setOficinas([]);
    setAceiteRegulamento(false);
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Inscrição no Evento</h2>

      {/* Inputs de texto para Nome e E-mail */}
      <div>
        <label>
          Nome:
          <input
            type="text"
            value={nome}
            onChange={(e) => setNome(e.target.value)}
          />
        </label>
      </div>

      <div>
        <label>
          E-mail:
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
      </div>

      {/* Radio Buttons para Tipo de Participante */}
      <div>
        <p>Tipo de Participante:</p>
        <label>
          <input
            type="radio"
            value="estudante"
            checked={tipoParticipante === 'estudante'}
            onChange={(e) => setTipoParticipante(e.target.value)}
          />
          Estudante
        </label>
        <label>
          <input
            type="radio"
            value="profissional"
            checked={tipoParticipante === 'profissional'}
            onChange={(e) => setTipoParticipante(e.target.value)}
          />
          Profissional
        </label>
      </div>

      {/* Select para Turno */}
      <div>
        <label>
          Turno:
          <select value={turno} onChange={(e) => setTurno(e.target.value)}>
            <option value="manha">Manhã</option>
            <option value="tarde">Tarde</option>
            <option value="noite">Noite</option>
          </select>
        </label>
      </div>

      {/* Checkboxes para Oficinas */}
      <div>
        <p>Oficinas:</p>
        <label>
          <input
            type="checkbox"
            value="frontend"
            checked={oficinas.includes('frontend')}
            onChange={handleOficina}
          />
          Front-end
        </label>
        <label>
          <input
            type="checkbox"
            value="backend"
            checked={oficinas.includes('backend')}
            onChange={handleOficina}
          />
          Back-end
        </label>
        <label>
          <input
            type="checkbox"
            value="dados"
            checked={oficinas.includes('dados')}
            onChange={handleOficina}
          />
          Dados
        </label>
        <label>
          <input
            type="checkbox"
            value="ia"
            checked={oficinas.includes('ia')}
            onChange={handleOficina}
          />
          IA
        </label>
      </div>

      {/* Checkbox para Aceite do Regulamento */}
      <div>
        <label>
          <input
            type="checkbox"
            checked={aceiteRegulamento}
            onChange={(e) => setAceiteRegulamento(e.target.checked)}
          />
          Li e aceito o regulamento
        </label>
      </div>

      {/* Botão de Envio */}
      <button type="submit" disabled={!aceiteRegulamento}>
        Enviar
      </button>
    </form>
  );
}

export default FormEvento;
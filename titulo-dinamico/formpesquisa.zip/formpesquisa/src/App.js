import logo from './logo.svg';
import './App.css';
import FormPesquisa from './componentes/FormPesquisa'

function App() {
  return (
    <FormPesquisa />
  );
}

export default App;
